module.exports = {
	siteUrl: "http://localhost:3000",
	hash_secret: "&qtt1ZZ*RI]b(#x,0 D.D;EDM_%n@gk0utoP(UU66~CzlMVPK^Ak{JRH].N>{k7/",
	jwt_secret: "&qtt1ZZ*RI]b(#x,0 D.D;EDM_%n@gk0utoP(UU66~CzlMVPK^Ak{JRH].N>{k7/",
}